require('./styles.scss');
const {cx, Icon} = require('@bsi-cx/design-build');

const hiddenInput = (i) => cx.part.formField.withId(`hidden-file-input-32ea01d7-${i}`).withLabel(`Hidden Input Label ${i}`);

module.exports = (
  template = require('./template.twig'),
  elementId = 'file-input-REEhtN',
  elementLabel = 'Mehrfach-Upload',
  elementDescription = 'erweitertes Upload-Element',
) => 
  cx
  .contentElement
  .withFile(template)
  .withElementId(elementId)
  .withLabel(elementLabel)
  .withDescription(elementDescription)
  .withIcon(Icon.FORMFIELD)
  .withParts(
    cx.part.plainText
      .withId('label-text-f95479ef')
      .withLabel('Label Text'),
    cx.part.plainText
      .withId('file-input-part-text-T9yfhp')
      .withLabel('Info Text'),
    cx.part.plainText
      .withId('file-input-part-error-required-904DIx')
      .withLabel('Fehlermeldung bei leerem Pflichtfeld'),
    cx.part.plainText
      .withId('file-input-part-error-max-count-b20f620c')
      .withLabel('Fehlermeldung bei überschrittener Anzahl Files'),
    cx.part.plainText
      .withId('file-input-part-error-invalid-5g1mUc')
      .withLabel('Fehlermeldung bei zu großem File'),
    hiddenInput(1),
    hiddenInput(2),
    hiddenInput(3),
    hiddenInput(4),
    hiddenInput(5),
    hiddenInput(6),
    hiddenInput(7),
    hiddenInput(8),
    hiddenInput(9),
  );