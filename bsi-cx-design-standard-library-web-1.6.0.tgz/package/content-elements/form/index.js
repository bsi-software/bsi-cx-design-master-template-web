const formElements = [
  require('./checkbox'),
  require('./dynamic-select'),
  require('./form-field'),
  require('./form-field-tel'),
  require('./regex-input'),
  require('./poll'),
  require('./radio'),
  require('./friendly-captcha'),
  require('./recaptcha'),
  require('./select'),
  require('./text-area'),
  require('./list'),
  require('./audiorecorder'),
  require('./advanced-file-upload')
];

module.exports.formElements = formElements;